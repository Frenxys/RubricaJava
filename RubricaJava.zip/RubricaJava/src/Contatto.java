
public class Contatto {
	private String email;
	private double numero;
	private String nome;
	public Contatto(String email,double numero,String nome) {
		setEmail(email);
		setNumero(numero);
		setNome(nome);
	}
	public String toString() {
		return "Contatto [email=" + email + ", numero=" + numero + ", nome=" + nome + "]";
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getNumero() {
		return numero;
	}
	public void setNumero(double numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
}
