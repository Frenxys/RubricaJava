import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
			Rubrica r=new Rubrica();
			r.caricaDaFile();
			r.visualizzaInformazioniMail("email1");
			
			
	}

}
