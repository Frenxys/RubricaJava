import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			int a=0;
			Rubrica r=new Rubrica();
			r.caricaDaFile();
			r.visualizzaInformazioniMail("email1");
			do {
				System.out.println("cosa vuoi fare?\n1)inserisci Contatto\n2)rimuovi contatto per mail\n3)rimuovi contatto per numero\n4)visualizza contatto per numero\n5)visualizza contatto per mail");
				a=sc.nextInt();
				switch(a) {
				case 1:break;
				case 2:break;
				case 3:break;
				case 4:break;
				case 5:break;
				}
			}while(true);
			
	}

}
