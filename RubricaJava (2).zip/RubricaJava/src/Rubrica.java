import java.io.*;

import java.util.LinkedList;

public class Rubrica {
	private LinkedList<Contatto> lista =new LinkedList<Contatto>();
	public Rubrica() {
		
	}
	public void aggiungi(Contatto c) {
		lista.add(c);
	}
	public void salvaSuFile() throws IOException{
		BufferedWriter writer=new BufferedWriter(new FileWriter("contatti.csv"));
		for(Contatto c:lista) {
			writer.write(c.getNome()+";"+c.getEmail()+";"+c.getNumero());
			writer.newLine();
		}
		writer.close();
	}
	public void caricaDaFile() throws IOException{
		BufferedReader reader=new BufferedReader(new FileReader("contatti.csv"));
		String linea="";
		while((linea=reader.readLine())!=null) {
			String[] linee=linea.split(";");
			lista.add(new Contatto(linee[1],Double.parseDouble(linee[2]),linee[1]));
		}
		reader.close();
	}
	public void visualizzaContattoNumero(double numero) {//visualizza contatto dato numero
		for (Contatto c:lista) {
			if(c.getNumero()==numero) {
				System.out.println(c);
			}
		
		}
	}
	public void eliminaContattoNumero(double numero) {//elimina contatto dato numero
		for (Contatto c:lista) {
			if(c.getNumero()==numero) {
				lista.remove(c);
			}
		
		}
	}
	public void visualizzaInformazioniMail(String email) { //visualizza contatto data email
		for (Contatto c:lista) {
			if(c.getEmail().contentEquals(email)) {
				System.out.println(c);
			}
		
		}
	}
	public void eliminaContattoEmail(String email) { //elimina contatto data email
		for (Contatto c:lista) {
			if(c.getEmail().contentEquals(email)) {
				lista.remove(c);
			}
		
		}
	}
}
